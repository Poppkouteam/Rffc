#!/bin/sh
# Rebuilds the working BRIGADA build from git history + critical fixes.
# Run from the repo root: sh brigada-handoff/build.sh  -> writes index.html, style.css, game.js in place.
set -e
H=$(dirname "$0"); T=$(mktemp -d)
git fetch -q --depth=200 origin 2>/dev/null || true
git show 8123d62:index.html > "$T/old.html"
git show b03b5ff:game.js > "$T/patch.js"
git show b03b5ff:style.css > "$T/style.css"
mkdir -p "$T/out"; python3 -I "$H/merge.py" "$T/old.html" "$T/patch.js" "$T/style.css" "$T/out"
git show b03b5ff:index.html > index.html
cp "$T/out/style.css" style.css
cp "$T/out/game.js" game.js
patch -s game.js < "$H/fix.patch"
md5sum game.js style.css index.html
echo "expected: 517c5cf9a220db93c776b75ed72a1e10 game.js / 1c049ec3dc60723af8fee1b6e48448c7 style.css / b58ad64f0c724e699eb0139d30c2eb1e index.html"
