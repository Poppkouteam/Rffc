#!/usr/bin/env python3
"""Rebuild a working 3-file БРИГАДА: engine from the last single-file build
(commit 8123d62/57158bf index.html, inline <script>) + the newer patch functions
from the current game.js (commit b03b5ff).

Usage: python3 -I merge.py OLD_INDEX_HTML PATCH_GAME_JS NEW_STYLE_CSS OUT_DIR
Writes OUT_DIR/game.js and OUT_DIR/style.css (index.html is copied unchanged by the caller).
"""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from blocks import find_block, get

old_html_p, patch_p, css_p, out_dir = sys.argv[1:5]
old_html = open(old_html_p, encoding='utf-8').read()
patch = open(patch_p, encoding='utf-8').read()
css = open(css_p, encoding='utf-8').read()

# ---- 1. engine = the inline <script> of the old single-file build -----------------
s = old_html.index('<script>\n// ====')  # inline engine (not the peerjs <script src>)
e = old_html.index('</script>', s)
eng = old_html[s + len('<script>\n'):e]

def replace_once(src, old, new, label):
    n = src.count(old)
    assert n == 1, f'{label}: expected 1 occurrence, found {n}'
    return src.replace(old, new)

def replace_func(src, name, new_text, label=None):
    r = find_block(src, name)
    assert r, f'function {name} not found'
    return src[:r[0]] + new_text + src[r[1]:]

def pblock(name, kind='function'):
    t = get(patch, name, kind)
    assert t, f'patch block {name} not found'
    return t

# ---- 2. PROGRESS: patch version (v2 key) + migration from old key + SETTINGS -------
progress_new = '''const PROGRESS_KEY = 'brigade_progress_v2';
const PROGRESS_KEY_OLD = 'brigade_progress'; // формат v1: { id: true }

function loadProgress() {
  try {
    const raw = localStorage.getItem(PROGRESS_KEY);
    if (raw) return JSON.parse(raw) || {};
    // Миграция со старой версии, чтобы игроки не потеряли пройденные миссии
    const oldRaw = localStorage.getItem(PROGRESS_KEY_OLD);
    if (oldRaw) {
      const old = JSON.parse(oldRaw) || {};
      const migrated = {};
      Object.keys(old).forEach(k => { if (old[k]) migrated[k] = { completed: true, time: Date.now() }; });
      localStorage.setItem(PROGRESS_KEY, JSON.stringify(migrated));
      console.log('[PROGRESS] Migrated from v1:', migrated);
      return migrated;
    }
    return {};
  } catch(e) { console.error('loadProgress error', e); return {}; }
}
''' + pblock('saveProgress') + '''function hasCompleted(missionId) {
  const p = loadProgress();
  // строго boolean: classList.toggle('completed', undefined) ПЕРЕКЛЮЧАЕТ класс, а не снимает его
  return !!(p[missionId] && p[missionId].completed === true);
}
''' + pblock('countCompleted') + '''function resetProgress() {
  try {
    localStorage.removeItem(PROGRESS_KEY);
    localStorage.removeItem(PROGRESS_KEY_OLD); // иначе loadProgress() снова мигрирует старый прогресс
    console.log('[PROGRESS] Reset');
  } catch(e){}
}

// ============================================================
//  SETTINGS — размеры джойстиков
// ============================================================
''' + pblock('SETTINGS_KEY', 'const') + pblock('loadSettings') + pblock('saveSettings') + pblock('applySettings')

old_progress = get(eng, 'loadProgress') + get(eng, 'saveProgress')
eng = replace_once(eng, old_progress, progress_new, 'PROGRESS')

# ---- 3. In-place function overrides (patch version is a strict superset) -----------
eng = replace_func(eng, 'drawMinimap', pblock('drawTutorialHintsPanel') + '\n' + pblock('drawMinimap'))
for name in ['throwGrenade', 'updateGrenades', 'updateBullets', 'gameOver', 'toMenu']:
    eng = replace_func(eng, name, pblock(name))
eng = replace_func(eng, 'togglePause', pblock('toggleSettingsPanel') + '\n' + pblock('togglePause'))

# ---- 4. Menu: drop tabs/pagination (ms-* DOM no longer exists) -> grouped menu -----
ms = eng.index('const MISSION_GROUPS = [')
r = find_block(eng, 'renderMissionTab')
eng = eng[:ms] + pblock('MISSION_GROUPS', 'const') + '\n' + pblock('initMissionSelect') + '\n' + pblock('refreshMenuProgress') + eng[r[1]:]
assert 'currentTab' not in eng and 'ms-tabs' not in eng

# ---- 5. Bootstrap: one animate() loop, via initGame() from the patch ---------------
ui_start = patch.index('// ============================================================\n//  ОБРАБОТЧИКИ UI')
ui_end = patch.index('// ============================================================\n//  TO MENU')
ui_block = patch[ui_start:ui_end]
init_block = '''// ============================================================
//  INIT — строго после готовности DOM (один цикл animate)
// ============================================================
''' + pblock('initGame') + '''
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initGame);
} else {
  initGame();
}
'''
eng = replace_once(eng, 'initMissionSelect();\nanimate();\n', ui_block + init_block, 'bootstrap')

# ---- 6. Fixes for things lost in the HTML rewrite / small robustness fixes ---------
# 6a. #want-plane-btn lost its inline onclick="activateAirMode()" -> bind like other in-game buttons
eng = replace_once(eng, "bindTap('tutorial-skip', () => skipTutorial());\n",
                   "bindTap('tutorial-skip', () => skipTutorial());\n"
                   "bindTap('want-plane-btn', () => activateAirMode()); // раньше был onclick в HTML\n", 'want-plane')
# 6b. Hotkeys must not fire while typing a cheat/coop code (F = fullscreen, G = grenade, E = orders...)
eng = replace_once(eng, "window.addEventListener('keydown', e => {\n  if (e.code === 'KeyR' && !airMode) reload();",
                   "window.addEventListener('keydown', e => {\n"
                   "  const typing = e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA');\n"
                   "  if (typing && e.code !== 'Enter') return;\n"
                   "  if (e.code === 'KeyR' && !airMode) reload();", 'hotkeys')
# 6c. Joystick travel follows the size chosen in settings (was hard-coded 40px for a 120px stick)
for fn in ['setupMoveJoystick', 'setupFireJoystick']:
    i = eng.index('(function ' + fn + '()')
    j = eng.index('})();', i)
    body = eng[i:j]
    body2 = body.replace('const maxDist = 40;', 'let maxDist = 40;', 1)
    body2 = body2.replace("const rect = el.getBoundingClientRect();\n",
                          "const rect = el.getBoundingClientRect();\n    maxDist = Math.max(24, rect.width * 0.34);\n", 1)
    assert body2 != body and body2.count('rect.width * 0.34') == 1, fn
    eng = eng[:i] + body2 + eng[j:]
# 6d. Tutorial text: in tutorial the top-left panel is now the colour legend, not a minimap
eng = replace_once(eng, "text:'МИНИКАРТА\\nСлева сверху — карта уровня.\\nВсе обозначения — в легенде.'",
                   "text:'ОБОЗНАЧЕНИЯ\\nСлева сверху — подсказки по цветам.\\nВ бою там будет миникарта.'", 'tutorial text')

# 6e. endTutorial(): deferred gameOver must not fire after the player left the tutorial
eng = replace_once(eng, """    log('✓ ОБУЧЕНИЕ ЗАВЕРШЕНО!', 'good');
    setTimeout(() => {
      gameOver(true, null, 'ОБУЧЕНИЕ ПРОЙДЕНО');
    }, 1500);""", """    log('✓ ОБУЧЕНИЕ ЗАВЕРШЕНО!', 'good');
    const tutorialRun = currentMission;
    setTimeout(() => {
      // игрок мог уже выйти в меню и запустить другую миссию
      if (currentMission === tutorialRun && !gameOverFlag) gameOver(true, null, 'ОБУЧЕНИЕ ПРОЙДЕНО');
    }, 1500);""", 'endTutorial')

header = '''// ============================================================
//  БРИГАДА — Тактический штурмовой симулятор
//  game.js = движок (последняя рабочая однофайловая версия)
//          + улучшения HUD v2 (меню без вкладок, настройки джойстиков,
//            отскок гранат, доводка пуль, надёжный прогресс)
// ============================================================
'''
open(os.path.join(out_dir, 'game.js'), 'w', encoding='utf-8').write(header + eng)

# ---- 7. CSS fixes -------------------------------------------------------------------
css_add = '''
/* ============================================================
   ВОССТАНОВЛЕНО / ФИКСЫ
   ============================================================ */
/* Канвас потерялся при переносе CSS в style.css */
#game-canvas { position:fixed; inset:0; display:block; z-index:1; }
/* На телефоне * { touch-action:none } запрещает прокрутку — разрешаем её в списках */
#missions-container, .group-cards, .legend-box { -webkit-overflow-scrolling: touch; }
/* В меню, легенде и экране итогов разрешаем прокрутку пальцем (у потомков тоже — touch-action пересекается по цепочке) */
#start-screen, #start-screen *, #tutorial-legend, #tutorial-legend *, #end-screen, #end-screen * { touch-action: pan-x pan-y; }
/* «БР» в заголовке было невидимым: background-clip:text родителя не красит inline-block потомка */
#easter-br { background:linear-gradient(180deg, #ffffff 0%, #a8d0f0 50%, #4a7aa0 100%); -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent; }
#easter-br.charging { -webkit-text-fill-color: var(--amber); }
/* Кнопки и HP-панель сдвигаются вместе с размером джойстиков из настроек */
#btn-weapon   { bottom: calc(var(--fire-size, 120px) + 48px); }
#btn-reload   { right: calc(var(--fire-size, 120px) + 10px); bottom: calc(var(--fire-size, 120px) + 48px); }
#btn-grenade  { right: calc(var(--fire-size, 120px) + 52px); }
#btn-commands { right: calc(var(--fire-size, 120px) + 52px); }
#hp-panel, #p2-panel { bottom: calc(var(--move-size, 120px) + 38px); }
body.pc-mode #hp-panel { bottom:20px; }
/* Меню приказов центрируется через translate(-50%,-50%), а общая анимация pauseSlideIn
   затирала transform — 0.25с меню висело со сдвигом вправо-вниз и потом «прыгало» */
#command-menu.active { animation: cmdSlideIn 0.25s; }
@keyframes cmdSlideIn { from { opacity:0; transform:translate(-50%,-46%) scale(0.94); } to { opacity:1; transform:translate(-50%,-50%) scale(1); } }
/* Телефон в альбомной ориентации (высота 320–500px): без этого список миссий ~30px,
   а кнопки паузы и «ПОНЯТНО» в легенде уходят за край экрана */
@media (max-height: 500px) {
  #start-screen { padding:8px 12px; gap:6px; }
  .menu-header { display:flex; align-items:center; justify-content:center; gap:16px; margin-top:0; }
  .menu-brand, .menu-slogan { display:none; }
  .menu-header h1 { font-size:24px; letter-spacing:8px; padding-left:8px; }
  .menu-progress { margin-top:0; padding:4px 12px; font-size:10px; letter-spacing:2px; }
  .menu-actions { gap:8px; }
  .menu-action-btn { flex-direction:row; gap:8px; min-width:0; padding:7px 14px; }
  .menu-action-btn .ma-icon { font-size:16px; margin-bottom:0; }
  .menu-action-btn .ma-sub { display:none; }
  .menu-footer { padding:0; }
  .menu-footer-btn { padding:5px 14px; }
  .mission-group { padding:6px 10px; }
  .group-header { margin-bottom:6px; }
  .mc-compact { padding:8px 6px; }
  .mc-num { font-size:22px; }
  #pause-menu { overflow-y:auto; align-items:flex-start; }
  .pause-box { margin:auto; padding:14px 22px 12px; gap:5px; }
  .pause-h { font-size:16px; margin-bottom:0; }
  .pause-divider { margin:2px 0 4px; }
  .pause-info { padding:6px 10px; margin-bottom:4px; line-height:1.45; }
  .p-btn { padding:7px 14px; }
  .p-btn .p-icon { width:26px; height:26px; font-size:14px; }
  .settings-row { padding:6px 8px; }
  #tutorial-legend { padding:8px; }
  .legend-box { padding:12px 16px; }
  .legend-title { margin-bottom:8px; font-size:14px; }
  .legend-subtitle { display:none; }
  .legend-grid { grid-template-columns:repeat(3, 1fr); gap:5px 8px; margin-bottom:10px; }
  .legend-item { padding:5px 8px; gap:8px; }
  .legend-icon { width:18px; height:18px; }
  .legend-label { font-size:11px; }
  .legend-label small { font-size:9px; margin-top:1px; }
  .legend-close { padding:9px; }
  #command-menu { padding:10px; }
  .cmd-title { margin-bottom:6px; }
  .cmd-btn { padding:6px 10px; }
  #end-screen h1 { font-size:18px; margin-bottom:4px; }
  #end-stats { padding:8px 18px; margin:6px; }
  .stat-row { padding:4px 0; }
}
'''
open(os.path.join(out_dir, 'style.css'), 'w', encoding='utf-8').write(css.rstrip() + '\n' + css_add)
print('OK: game.js', len(header + eng), 'bytes;', (header + eng).count('\n'), 'lines')
