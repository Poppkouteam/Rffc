import re
def find_block(src, name, kind='function'):
    """Return (start,end) char offsets of a top-level block starting at column 0.
    kind='function' -> 'function NAME(' ... until matching close brace (brace counting, skipping strings/comments/templates)."""
    if kind == 'function':
        m = re.search(r'^function\s+' + re.escape(name) + r'\s*\(', src, flags=re.M)
    else:
        m = re.search(r'^(?:const|let|var)\s+' + re.escape(name) + r'\b', src, flags=re.M)
    if not m: return None
    i = m.start(); n = len(src); depth = 0; seen = False
    j = i
    while j < n:
        c = src[j]
        if c in '\'"':
            q = c; j += 1
            while j < n and src[j] != q:
                if src[j] == '\\': j += 1
                j += 1
        elif c == '`':
            j += 1; tdepth = 0
            while j < n:
                if src[j] == '\\': j += 2; continue
                if src[j] == '`' and tdepth == 0: break
                if src[j:j+2] == '${': tdepth += 1; j += 2; continue
                if src[j] == '}' and tdepth > 0: tdepth -= 1
                j += 1
        elif src[j:j+2] == '//':
            while j < n and src[j] != '\n': j += 1
            continue
        elif src[j:j+2] == '/*':
            j = src.index('*/', j) + 1
        elif c in '{[(':
            depth += 1; seen = True
        elif c in '}])':
            depth -= 1
            if seen and depth == 0:
                if kind == 'function' and c == '}':
                    end = j + 1
                    if end < n and src[end] == '\n': end += 1
                    return (i, end)
        elif c == ';' and kind != 'function' and depth == 0:
            end = j + 1
            if end < n and src[end] == '\n': end += 1
            return (i, end)
        j += 1
    return None
def get(src, name, kind='function'):
    r = find_block(src, name, kind)
    return src[r[0]:r[1]] if r else None
